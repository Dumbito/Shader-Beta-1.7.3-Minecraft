#version 330 compatibility

// ---- /lib/config.glsl ----
// Beta173 Lighting — reconstruccion de la distancia de renderizado de Beta 1.7.3.
// Selector manual: 0 = Far, 1 = Normal, 2 = Short, 3 = Tiny.
// Esto reproduce la matematica historica; no controla los chunks de Iris.

#define BETA_THUNDER
#define BETA_NETHER_AMBIENT
#define BETA_FOG

// Equivalente a GameSettings.renderDistance en Beta 1.7.3.
#define BETA_RENDER_DISTANCE 0

// EntityRenderer.setupCameraTransform y EntityRenderer.updateFogColor.
#if BETA_RENDER_DISTANCE == 0
    #define BETA_FOG_END 256.0
    #define BETA_FOG_SKY_BLEND 0.2928932
#elif BETA_RENDER_DISTANCE == 1
    #define BETA_FOG_END 128.0
    #define BETA_FOG_SKY_BLEND 0.2401643
#elif BETA_RENDER_DISTANCE == 2
    #define BETA_FOG_END 64.0
    #define BETA_FOG_SKY_BLEND 0.1591036
#elif BETA_RENDER_DISTANCE == 3
    #define BETA_FOG_END 32.0
    #define BETA_FOG_SKY_BLEND 0.0
#else
    #error BETA_RENDER_DISTANCE debe ser 0, 1, 2 o 3
#endif

// Fallback solo para rutas de dimensión sin cielo. En el Overworld:
// - el ZIP universal usa automáticamente el uniforme Iris "temperature" si no conoce la semilla;
// - Beta173 Climate Bridge activa el campo histórico exacto en mundos de un jugador;
// - un ZIP específico de semilla usa climate_seed.glsl + climate_noise.glsl.
#define BETA_SKY_TEMPERATURE 0.5

// ---------------------------------------------------------------------------
// Estrellas, nubes y diagnostico (v0.8)
// ---------------------------------------------------------------------------

// Estrellas de Beta dibujadas por este shader dentro del cielo (RenderGlobal.renderStars:
// java.util.Random(10842), 1500 intentos -> 780 estrellas, radio 100, mismo tamano y rotacion).
// No dependen del pase de estrellas del motor, que se descarta. Comenta la linea para volver
// al pase del motor.
#define BETA_STAR_FIELD

// Geometría experimental de nubes Beta mediante geometry shader.
// 0 = geometría nativa de Minecraft + color/sombreado Beta (modo estable por defecto).
// 1 = malla reconstruida de Beta (experimental; puede depender del particionado de draws Iris).
// La opción se puede cambiar desde Shader Pack Settings; no hace falta editar este archivo.
#define BETA_CUSTOM_CLOUD_GEOMETRY 0 // [0 1]

// Color de las nubes:
//   0 = color y sombreado de Beta (World.drawClouds + caras 1.0 / 0.7 / 0.9 / 0.8). Ignora el
//       color del motor, asi que no puede haber oscurecimiento doble.
//   1 = solo el color que da el motor, sin tocarlo.
//   2 = comportamiento de v0.7.2: el color de Beta se multiplica sobre el del motor.
#define BETA_CLOUD_COLOR_MODE 0

// Altura de las nubes. Beta: WorldProvider.getCloudHeight() = 108, mas 0.33 en el render.
// BETA_VANILLA_CLOUD_HEIGHT es la altura que usa el juego moderno (192.33 desde 1.18).
// Comenta BETA_CLOUD_HEIGHT_FIX para dejar las nubes a la altura del juego.
#define BETA_CLOUD_HEIGHT_FIX
#define BETA_VANILLA_CLOUD_HEIGHT 192.33
// Altura moderna: remapea la proporción de Beta (108.33/128)
// al rango Overworld [-64, 320]: -64 + (108.33/128)*384 ~= 260.99.
#define BETA_CLOUD_HEIGHT 260.99

#ifdef BETA_CLOUD_HEIGHT_FIX
    #define BETA_CLOUD_BASE BETA_CLOUD_HEIGHT
#else
    #define BETA_CLOUD_BASE BETA_VANILLA_CLOUD_HEIGHT
#endif

// BETA_DEBUG:
//   0 = apagado (comportamiento normal)
//   1 = cada etapa del cielo se pinta de un color y las nubes salen rojas y opacas:
//         azul = SKY, naranja = SUNSET, MAGENTA = STARS, verde = CUSTOM_SKY,
//         rojo oscuro = VOID, AMARILLO = etapa no reconocida
//   2 = estrellas de Beta al maximo brillo (aunque sea de dia, para ver el mapa)
//   3 = el cielo muestra uniformes: R = lluvia, G = tormenta, B = brillo de estrellas x2
//       (si todo el cielo sale BLANCO, el uniforme hasSkylight no llega al shader)
//   4 = anillo CIAN alrededor de donde Beta pone el sol y anillo NARANJA donde pone la luna;
//       si el sol y la luna del juego quedan centrados en sus anillos, el marco de las estrellas es correcto
#define BETA_DEBUG 0

// ---- fin /lib/config.glsl ----

layout(triangles) in;
layout(triangle_strip, max_vertices = 64) out;

in vec4 sourceCloudColor[];
in vec3 sourceCloudViewPos[];

out vec4 cloudColor;
out vec3 cloudViewPos;
out vec2 betaCloudUV;
flat out float betaCloudShade;

uniform mat4 gbufferModelView;
uniform mat4 gbufferProjection;
uniform vec3 cameraPosition;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform int worldTime;
uniform int worldDay;

const int BETA_CLOUD_TILE_COUNT = 6;
const int BETA_CLOUD_SEGMENTS = 8;
const int BETA_CLOUD_TILE_SIZE = 96;
const int BETA_CLOUD_GRID_SIZE = 3072;
const int BETA_CLOUD_TEXTURE_SIZE = 256;
const float BETA_CLOUD_SEGMENT_SIZE = 12.0;
const float BETA_CLOUD_TEXTURE_STEP = 1.0 / 256.0;
const float BETA_CLOUD_EDGE_EPSILON = 0.0009765625;

int betaCloudWrapInt(int value, int period) {
    int wrapped = value % period;
    return wrapped < 0 ? wrapped + period : wrapped;
}

float betaCloudScrollBlocks() {
    // World.drawClouds: cloudOffsetX advances 1/tick, then * 0.03 blocks.
    // The texture repeats every 3072 blocks (256 cells * 12 blocks).
    // 128 days * 24000 ticks is a whole number of 3072-block cloud cycles.
    float day = mod(float(worldDay), 128.0);
    float ticks = mod(day * 24000.0 + float(worldTime), 102400.0);
    return ticks * 0.03;
}

void betaCloudEmitVertex(vec3 relativePosition, vec2 uv, float shade) {
    vec4 viewPosition = gbufferModelView * vec4(relativePosition, 1.0);
    gl_Position = gbufferProjection * viewPosition;
    cloudColor = vec4(1.0);
    cloudViewPos = viewPosition.xyz;
    betaCloudUV = uv;
    betaCloudShade = shade;
    EmitVertex();
}

void betaCloudEmitQuad(
    vec3 p0, vec3 p1, vec3 p2, vec3 p3,
    vec2 uv0, vec2 uv1, vec2 uv2, vec2 uv3,
    float shade
) {
    betaCloudEmitVertex(p0, uv0, shade);
    betaCloudEmitVertex(p1, uv1, shade);
    betaCloudEmitVertex(p2, uv2, shade);
    betaCloudEmitVertex(p3, uv3, shade);
    EndPrimitive();
}

void betaCloudEmitCellFace(
    int faceInCell, int cellX, int cellZ,
    float x0, float x1, float z0, float z1,
    float bottomY, float topY, int baseGridX, int baseGridZ
) {
    float u0 = float(betaCloudWrapInt(baseGridX + cellX * 8, BETA_CLOUD_TEXTURE_SIZE)) * BETA_CLOUD_TEXTURE_STEP;
    float u1 = float(betaCloudWrapInt(baseGridX + (cellX + 1) * 8, BETA_CLOUD_TEXTURE_SIZE)) * BETA_CLOUD_TEXTURE_STEP;
    float v0 = float(betaCloudWrapInt(baseGridZ + cellZ * 8, BETA_CLOUD_TEXTURE_SIZE)) * BETA_CLOUD_TEXTURE_STEP;
    float v1 = float(betaCloudWrapInt(baseGridZ + (cellZ + 1) * 8, BETA_CLOUD_TEXTURE_SIZE)) * BETA_CLOUD_TEXTURE_STEP;
    int localFace = faceInCell;

    // Beta top and bottom planes: one 96x96-block quad, texture region 8x8 pixels.
    if (localFace == 0) {
        if (bottomY <= 5.0) {
            betaCloudEmitQuad(
                vec3(x0, topY, z1), vec3(x1, topY, z1),
                vec3(x1, topY, z0), vec3(x0, topY, z0),
                vec2(u0, v1), vec2(u1, v1), vec2(u1, v0), vec2(u0, v0), 1.0
            );
        }
        return;
    }
    localFace -= 1;

    if (localFace == 0) {
        if (bottomY > -5.0) {
            betaCloudEmitQuad(
                vec3(x0, bottomY, z0), vec3(x1, bottomY, z0),
                vec3(x1, bottomY, z1), vec3(x0, bottomY, z1),
                vec2(u0, v0), vec2(u1, v0), vec2(u1, v1), vec2(u0, v1), 0.7
            );
        }
        return;
    }
    localFace -= 1;

    // Walls parallel to Z: shade 0.9, one face at each 12-block X segment.
    if (cellX > -1) {
        if (localFace < BETA_CLOUD_SEGMENTS) {
            int segment = localFace;
            float x = x0 + float(segment) * BETA_CLOUD_SEGMENT_SIZE;
            float u = fract((float(baseGridX + cellX * 8 + segment) + 0.5) * BETA_CLOUD_TEXTURE_STEP);
            betaCloudEmitQuad(
                vec3(x, bottomY, z1), vec3(x, topY, z1),
                vec3(x, topY, z0), vec3(x, bottomY, z0),
                vec2(u, v1), vec2(u, v1), vec2(u, v0), vec2(u, v0), 0.9
            );
            return;
        }
        localFace -= BETA_CLOUD_SEGMENTS;
    }

    if (cellX <= 1) {
        if (localFace < BETA_CLOUD_SEGMENTS) {
            int segment = localFace;
            float x = x0 + (float(segment + 1) - BETA_CLOUD_EDGE_EPSILON) * BETA_CLOUD_SEGMENT_SIZE;
            float u = fract((float(baseGridX + cellX * 8 + segment) + 0.5) * BETA_CLOUD_TEXTURE_STEP);
            betaCloudEmitQuad(
                vec3(x, bottomY, z1), vec3(x, topY, z1),
                vec3(x, topY, z0), vec3(x, bottomY, z0),
                vec2(u, v1), vec2(u, v1), vec2(u, v0), vec2(u, v0), 0.9
            );
            return;
        }
        localFace -= BETA_CLOUD_SEGMENTS;
    }

    // Walls parallel to X: shade 0.8, one face at each 12-block Z segment.
    if (cellZ > -1) {
        if (localFace < BETA_CLOUD_SEGMENTS) {
            int segment = localFace;
            float z = z0 + float(segment) * BETA_CLOUD_SEGMENT_SIZE;
            float v = fract((float(baseGridZ + cellZ * 8 + segment) + 0.5) * BETA_CLOUD_TEXTURE_STEP);
            betaCloudEmitQuad(
                vec3(x0, topY, z), vec3(x1, topY, z),
                vec3(x1, bottomY, z), vec3(x0, bottomY, z),
                vec2(u0, v), vec2(u1, v), vec2(u1, v), vec2(u0, v), 0.8
            );
            return;
        }
        localFace -= BETA_CLOUD_SEGMENTS;
    }

    if (cellZ <= 1) {
        if (localFace < BETA_CLOUD_SEGMENTS) {
            int segment = localFace;
            float z = z0 + (float(segment + 1) - BETA_CLOUD_EDGE_EPSILON) * BETA_CLOUD_SEGMENT_SIZE;
            float v = fract((float(baseGridZ + cellZ * 8 + segment) + 0.5) * BETA_CLOUD_TEXTURE_STEP);
            betaCloudEmitQuad(
                vec3(x0, topY, z), vec3(x1, topY, z),
                vec3(x1, bottomY, z), vec3(x0, bottomY, z),
                vec2(u0, v), vec2(u1, v), vec2(u1, v), vec2(u0, v), 0.8
            );
        }
    }
}

void betaCloudEmitFaceOrdinal(int faceOrdinal) {
    int remaining = faceOrdinal;
    float cameraXModulo = float(betaCloudWrapInt(cameraPositionInt.x, BETA_CLOUD_GRID_SIZE));
    float cameraZModulo = float(betaCloudWrapInt(cameraPositionInt.z, BETA_CLOUD_GRID_SIZE));
    float scrollX = betaCloudScrollBlocks();
    float gridXFloat = (cameraXModulo + cameraPositionFract.x + scrollX) / BETA_CLOUD_SEGMENT_SIZE;
    float gridZFloat = (cameraZModulo + cameraPositionFract.z) / BETA_CLOUD_SEGMENT_SIZE + 0.33000001311302185;
    float fracX = fract(gridXFloat);
    float fracZ = fract(gridZFloat);
    int baseGridX = betaCloudWrapInt(int(floor(gridXFloat)), BETA_CLOUD_TEXTURE_SIZE);
    int baseGridZ = betaCloudWrapInt(int(floor(gridZFloat)), BETA_CLOUD_TEXTURE_SIZE);

    float bottomY = BETA_CLOUD_BASE + 0.33 - cameraPosition.y;
    float topY = BETA_CLOUD_BASE + 4.33 - BETA_CLOUD_EDGE_EPSILON - cameraPosition.y;

    for (int tileX = 0; tileX < BETA_CLOUD_TILE_COUNT; ++tileX) {
        for (int tileZ = 0; tileZ < BETA_CLOUD_TILE_COUNT; ++tileZ) {
            int cellX = tileX - 2;
            int cellZ = tileZ - 2;
            int cellFaceCount = 2
                + (cellX > -1 ? BETA_CLOUD_SEGMENTS : 0)
                + (cellX <= 1 ? BETA_CLOUD_SEGMENTS : 0)
                + (cellZ > -1 ? BETA_CLOUD_SEGMENTS : 0)
                + (cellZ <= 1 ? BETA_CLOUD_SEGMENTS : 0);

            if (remaining >= cellFaceCount) {
                remaining -= cellFaceCount;
                continue;
            }

            float x0 = float(cellX * BETA_CLOUD_TILE_SIZE) - fracX * BETA_CLOUD_SEGMENT_SIZE;
            float x1 = x0 + float(BETA_CLOUD_TILE_SIZE);
            float z0 = float(cellZ * BETA_CLOUD_TILE_SIZE) - fracZ * BETA_CLOUD_SEGMENT_SIZE;
            float z1 = z0 + float(BETA_CLOUD_TILE_SIZE);
            betaCloudEmitCellFace(
                remaining, cellX, cellZ, x0, x1, z0, z1,
                bottomY, topY, baseGridX, baseGridZ
            );
            return;
        }
    }
}

void main() {
#if BETA_CUSTOM_CLOUD_GEOMETRY
    // One source triangle dispatches 16 historical faces; 53 triangles cover all 840.
    // The geometry is emitted inside the native cloud draw to retain scene depth testing.
    int firstFace = gl_PrimitiveIDIn * 16;
    if (firstFace >= 840) return;
    for (int i = 0; i < 16; ++i) {
        int face = firstFace + i;
        if (face < 840) betaCloudEmitFaceOrdinal(face);
    }
#else
    // Modo estable: passthrough del mesh nativo. No depende de gl_PrimitiveIDIn
    // para reconstruir una malla global, porque Iris puede dividirlo en varios draws.
    for (int i = 0; i < 3; ++i) {
        gl_Position = gl_in[i].gl_Position;
        cloudColor = sourceCloudColor[i];
        cloudViewPos = sourceCloudViewPos[i];
        betaCloudUV = vec2(0.0);
        betaCloudShade = 1.0;
        EmitVertex();
    }
    EndPrimitive();
#endif
}
