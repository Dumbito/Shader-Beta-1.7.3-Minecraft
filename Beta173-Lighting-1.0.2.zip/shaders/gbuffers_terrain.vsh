#version 330 compatibility

// ---- /lib/beta173.glsl ----
// Beta173 Lighting - funciones portadas desde el codigo de Minecraft Beta 1.7.3
// Referencia: WorldProvider, WorldProviderHell, World, EntityRenderer y RenderGlobal
// (https://github.com/jacobo-mc/mc_b1.7.3_release)

// ---- /lib/config.glsl ----
// Beta173 Lighting — reconstruccion de la distancia de renderizado de Beta 1.7.3.
// Selector manual: 0 = Far, 1 = Normal, 2 = Short, 3 = Tiny.
// Esto reproduce la matematica historica; no controla los chunks de Iris.

#define BETA_THUNDER
#define BETA_NETHER_AMBIENT
#define BETA_FOG

// Equivalente a GameSettings.renderDistance en Beta 1.7.3.
#define BETA_RENDER_DISTANCE 0

// EntityRenderer.setupCameraTransform y EntityRenderer.updateFogColor.
#if BETA_RENDER_DISTANCE == 0
    #define BETA_FOG_END 256.0
    #define BETA_FOG_SKY_BLEND 0.2928932
#elif BETA_RENDER_DISTANCE == 1
    #define BETA_FOG_END 128.0
    #define BETA_FOG_SKY_BLEND 0.2401643
#elif BETA_RENDER_DISTANCE == 2
    #define BETA_FOG_END 64.0
    #define BETA_FOG_SKY_BLEND 0.1591036
#elif BETA_RENDER_DISTANCE == 3
    #define BETA_FOG_END 32.0
    #define BETA_FOG_SKY_BLEND 0.0
#else
    #error BETA_RENDER_DISTANCE debe ser 0, 1, 2 o 3
#endif

// Fallback solo para rutas de dimensión sin cielo. En el Overworld:
// - el ZIP universal usa automáticamente el uniforme Iris "temperature" si no conoce la semilla;
// - Beta173 Climate Bridge activa el campo histórico exacto en mundos de un jugador;
// - un ZIP específico de semilla usa climate_seed.glsl + climate_noise.glsl.
#define BETA_SKY_TEMPERATURE 0.5

// ---------------------------------------------------------------------------
// Estrellas, nubes y diagnostico (v0.8)
// ---------------------------------------------------------------------------

// Estrellas de Beta dibujadas por este shader dentro del cielo (RenderGlobal.renderStars:
// java.util.Random(10842), 1500 intentos -> 780 estrellas, radio 100, mismo tamano y rotacion).
// No dependen del pase de estrellas del motor, que se descarta. Comenta la linea para volver
// al pase del motor.
#define BETA_STAR_FIELD

// Geometría experimental de nubes Beta mediante geometry shader.
// 0 = geometría nativa de Minecraft + color/sombreado Beta (modo estable por defecto).
// 1 = malla reconstruida de Beta (experimental; puede depender del particionado de draws Iris).
// La opción se puede cambiar desde Shader Pack Settings; no hace falta editar este archivo.
#define BETA_CUSTOM_CLOUD_GEOMETRY 0 // [0 1]

// Horario de nubes: visibles durante el día, ocultas por completo por la noche.
// Ajustables desde Shader Pack Settings; no hace falta editar GLSL.
// Amanecer cruza el tick 24000: empieza antes de 0 y termina de aparecer al tick 1000.
#define BETA_CLOUD_DAWN_START_TICK 22000.0 // [21000 21500 22000 22500 23000]
#define BETA_CLOUD_DAWN_END_TICK 1000.0 // [500 1000 1500 2000 2500]
// Al anochecer desaparecen progresivamente entre los ticks 12000 y 13500.
#define BETA_CLOUD_DUSK_START_TICK 12000.0 // [11000 11500 12000 12500]
#define BETA_CLOUD_DUSK_END_TICK 13500.0 // [13000 13500 14000 14500 15000]


// Color de las nubes:
//   0 = color y sombreado de Beta (World.drawClouds + caras 1.0 / 0.7 / 0.9 / 0.8). Ignora el
//       color del motor, asi que no puede haber oscurecimiento doble.
//   1 = solo el color que da el motor, sin tocarlo.
//   2 = comportamiento de v0.7.2: el color de Beta se multiplica sobre el del motor.
#define BETA_CLOUD_COLOR_MODE 0

// Altura de las nubes. Beta: WorldProvider.getCloudHeight() = 108, mas 0.33 en el render.
// BETA_VANILLA_CLOUD_HEIGHT es la altura que usa el juego moderno (192.33 desde 1.18).
// Comenta BETA_CLOUD_HEIGHT_FIX para dejar las nubes a la altura del juego.
#define BETA_CLOUD_HEIGHT_FIX
#define BETA_VANILLA_CLOUD_HEIGHT 192.33
// Altura moderna: remapea la proporción de Beta (108.33/128)
// al rango Overworld [-64, 320]: -64 + (108.33/128)*384 ~= 260.99.
#define BETA_CLOUD_HEIGHT 260.99

#ifdef BETA_CLOUD_HEIGHT_FIX
    #define BETA_CLOUD_BASE BETA_CLOUD_HEIGHT
#else
    #define BETA_CLOUD_BASE BETA_VANILLA_CLOUD_HEIGHT
#endif

// BETA_DEBUG:
//   0 = apagado (comportamiento normal)
//   1 = cada etapa del cielo se pinta de un color y las nubes salen rojas y opacas:
//         azul = SKY, naranja = SUNSET, MAGENTA = STARS, verde = CUSTOM_SKY,
//         rojo oscuro = VOID, AMARILLO = etapa no reconocida
//   2 = estrellas de Beta al maximo brillo (aunque sea de dia, para ver el mapa)
//   3 = el cielo muestra uniformes: R = lluvia, G = tormenta, B = brillo de estrellas x2
//       (si todo el cielo sale BLANCO, el uniforme hasSkylight no llega al shader)
//   4 = anillo CIAN alrededor de donde Beta pone el sol y anillo NARANJA donde pone la luna;
//       si el sol y la luna del juego quedan centrados en sus anillos, el marco de las estrellas es correcto
#define BETA_DEBUG 0

// ---- fin /lib/config.glsl ----
// ---- /lib/climate_seed.glsl ----
// Reserva por defecto. tools/configure_climate_pack.py genera este archivo con la semilla real.
// No edites estas constantes: el ZIP de cada mundo incluye sus propios datos generados.
#define BETA_CLIMATE_SEED_CONFIGURED 0
const vec2 BETA_CLIMATE_OFFSET_0 = vec2(0.0, 0.0);
const vec2 BETA_CLIMATE_OFFSET_1 = vec2(0.0, 0.0);
const vec2 BETA_CLIMATE_OFFSET_2 = vec2(0.0, 0.0);
const vec2 BETA_CLIMATE_OFFSET_3 = vec2(0.0, 0.0);

// ---- fin /lib/climate_seed.glsl ----
// ---- /lib/climate_noise.glsl ----
// Port GLSL de NoiseGenerator2 + NoiseGeneratorOctaves2 de Beta 1.7.3.
// El script genera una textura de índices de gradiente desde la semilla original.
// Se usa float GLSL, por lo que no puede ser bit a bit idéntico al double de Java.
uniform sampler2D beta173ClimateGradient;

const float BETA_CLIMATE_F2 = 0.3660254037844386;
const float BETA_CLIMATE_G2 = 0.21132486540518713;
const float BETA_CLIMATE_SCALE = 0.02500000037252903 / 1.5;

int beta173ClimateWrap(float value) {
    // Equivale al helper wrap de NoiseGenerator2, incluso para coordenadas negativas.
    return value > 0.0 ? int(value) : int(value) - 1;
}

int beta173ClimateGradientIndex(int x, int z, int octave) {
    // La textura PNG se guarda con filas invertidas para compensar el orden de upload de Iris.
    // El inverso vertical recupera la celda original octave/z; una lectura por esquina.
    int textureY = 1023 - (octave * 256 + (z & 255));
    float encoded = texelFetch(beta173ClimateGradient,
                               ivec2(x & 255, textureY), 0).r;
    return int(floor(encoded * 255.0 + 0.5));
}

vec2 beta173ClimateGradientVector(int index) {
    // Primeras dos componentes de los 12 gradientes usados por NoiseGenerator2.
    if (index == 0) return vec2( 1.0,  1.0);
    if (index == 1) return vec2(-1.0,  1.0);
    if (index == 2) return vec2( 1.0, -1.0);
    if (index == 3) return vec2(-1.0, -1.0);
    if (index == 4) return vec2( 1.0,  0.0);
    if (index == 5) return vec2(-1.0,  0.0);
    if (index == 6) return vec2( 1.0,  0.0);
    if (index == 7) return vec2(-1.0,  0.0);
    if (index == 8) return vec2( 0.0,  1.0);
    if (index == 9) return vec2( 0.0, -1.0);
    if (index == 10) return vec2(0.0, 1.0);
    return vec2(0.0, -1.0);
}

float beta173ClimateCorner(vec2 p, int gradientIndex) {
    float attenuation = 0.5 - dot(p, p);
    if (attenuation < 0.0) return 0.0;
    attenuation *= attenuation;
    return attenuation * attenuation * dot(beta173ClimateGradientVector(gradientIndex), p);
}

float beta173ClimateSimplex(vec2 point, int octave) {
    float skew = (point.x + point.y) * BETA_CLIMATE_F2;
    int i = beta173ClimateWrap(point.x + skew);
    int j = beta173ClimateWrap(point.y + skew);
    float unskew = float(i + j) * BETA_CLIMATE_G2;
    float x0 = point.x - (float(i) - unskew);
    float z0 = point.y - (float(j) - unskew);

    int i1 = x0 > z0 ? 1 : 0;
    int j1 = x0 > z0 ? 0 : 1;
    vec2 p0 = vec2(x0, z0);
    vec2 p1 = vec2(x0 - float(i1) + BETA_CLIMATE_G2,
                    z0 - float(j1) + BETA_CLIMATE_G2);
    vec2 p2 = vec2(x0 - 1.0 + 2.0 * BETA_CLIMATE_G2,
                    z0 - 1.0 + 2.0 * BETA_CLIMATE_G2);

    int g0 = beta173ClimateGradientIndex(i, j, octave);
    int g1 = beta173ClimateGradientIndex(i + i1, j + j1, octave);
    int g2 = beta173ClimateGradientIndex(i + 1, j + 1, octave);
    return 70.0 * (beta173ClimateCorner(p0, g0)
                 + beta173ClimateCorner(p1, g1)
                 + beta173ClimateCorner(p2, g2));
}

vec2 beta173ClimateOffset(int octave) {
    if (octave == 0) return BETA_CLIMATE_OFFSET_0;
    if (octave == 1) return BETA_CLIMATE_OFFSET_1;
    if (octave == 2) return BETA_CLIMATE_OFFSET_2;
    return BETA_CLIMATE_OFFSET_3;
}

float beta173ClimateTemperature(vec2 blockXZ) {
    float value = 0.0;
    float frequency = 1.0;
    float amplitude = 1.0;
    for (int octave = 0; octave < 4; ++octave) {
        vec2 point = blockXZ * (BETA_CLIMATE_SCALE * frequency) + beta173ClimateOffset(octave);
        value += beta173ClimateSimplex(point, octave) * (0.55 / amplitude);
        frequency *= 0.5;
        amplitude *= 0.5;
    }
    return value;
}

// ---- fin /lib/climate_noise.glsl ----

uniform vec3 cameraPosition;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform vec3 eyePosition;
uniform vec3 relativeEyePosition;

uniform float temperature; // Iris: temperatura base del bioma actual (fallback universal).
uniform float beta173LegacyClimateTemperature;
uniform vec3 beta173LegacySkyRgb; // RGB histórico de 8 bits, calculado con aritmética Java.
uniform bool beta173LegacyClimateAvailable; // true si el bridge conoce la semilla real del mundo.

uniform int worldTime;
uniform float rainStrength;
uniform float thunderStrength; // Iris lo entrega ya ponderado por la lluvia, igual que getWeightedThunderStrength
uniform bool hasSkylight;      // false en Nether y End
uniform bool hasCeiling;       // true en dimensiones con techo, como el Nether
uniform float ambientLight;    // luz ambiental nativa de la dimensión, expuesta por Iris
uniform vec3 fogColor;          // color de niebla nativo de Minecraft expuesto por Iris
uniform float fogStart;         // inicio de niebla nativo
uniform float fogEnd;           // fin de niebla nativo
uniform float fogDensity;       // densidad de niebla nativa
uniform int fogMode;             // 2048 EXP, 2049 EXP2, 9729 LINEAR
uniform int isEyeInWater;      // 0 aire, 1 agua, 2 lava

const float BETA_PI = 3.14159265359;

float beta173Rain() {
    return rainStrength;
}

float beta173Thunder() {
#ifdef BETA_THUNDER
    return thunderStrength;
#else
    return 0.0;
#endif
}

float beta173CelestialAngle() {
    float angle = mod(float(worldTime), 24000.0) / 24000.0 - 0.25;
    if (angle < 0.0) angle += 1.0;
    if (angle > 1.0) angle -= 1.0;

    float original = angle;
    angle = 1.0 - (cos(angle * BETA_PI) + 1.0) / 2.0;
    return original + (angle - original) / 3.0;
}

// cos(angulo * 2pi) * 2 + 0.5, limitado a 0..1 (base de cielo, niebla y luz)
float beta173DayFactor() {
    return clamp(cos(beta173CelestialAngle() * BETA_PI * 2.0) * 2.0 + 0.5, 0.0, 1.0);
}

// World.calculateSkylightSubtracted
float beta173SkySubtracted() {
    float f = beta173DayFactor();
    f *= 1.0 - beta173Rain() * 5.0 / 16.0;
    f *= 1.0 - beta173Thunder() * 5.0 / 16.0;
    return floor((1.0 - f) * 11.0);
}

// WorldProvider.generateLightBrightnessTable (0.1 en el Nether)
float beta173Ambient() {
#ifdef BETA_NETHER_AMBIENT
    if (!hasSkylight && hasCeiling) return 0.1;
#endif
    if (!hasSkylight && !hasCeiling) return ambientLight;
    return 0.05;
}

float beta173Brightness(float level) {
    float ambient = beta173Ambient();
    float inverted = 1.0 - level / 15.0;
    return (1.0 - inverted) / (inverted * 3.0 + 1.0) * (1.0 - ambient) + ambient;
}

// Nivel de luz efectivo: max(luz de bloque, luz de cielo - restado)
float beta173LightLevel(vec2 lm) {
    float block = clamp(lm.x, 0.0, 1.0) * 15.0;
    float sky = clamp(lm.y, 0.0, 1.0) * 15.0;
#ifndef BETA_SMOOTH
    block = floor(block + 0.5);
    sky = floor(sky + 0.5);
#endif
    return max(block, max(0.0, sky - beta173SkySubtracted()));
}

// Port de java.awt.Color.getHSBColor / HSBtoRGB: sectores HSV y cuantizacion RGB de 8 bits.
// Java convierte cada canal mediante (int)(canal * 255), es decir, truncamiento y no redondeo.
vec3 beta173Hsb(float h, float s, float b) {
    h = fract(h) * 6.0;
    int sector = int(h);
    float f = h - float(sector);
    float p = b * (1.0 - s);
    float q = b * (1.0 - s * f);
    float t = b * (1.0 - s * (1.0 - f));
    vec3 rgb;
    if (sector == 0) rgb = vec3(b, t, p);
    else if (sector == 1) rgb = vec3(q, b, p);
    else if (sector == 2) rgb = vec3(p, b, t);
    else if (sector == 3) rgb = vec3(p, q, b);
    else if (sector == 4) rgb = vec3(t, p, b);
    else rgb = vec3(b, p, q);
    return floor(clamp(rgb, 0.0, 1.0) * 255.0) / 255.0;
}

// Temperatura climática de Beta, basada en la semilla y las coordenadas X/Z del jugador.
// En el pase del cielo se calcula en el vertex shader y se interpola como flat para no
// recalcular el ruido cuatro-octavas en cada fragmento de pantalla.
float beta173SkyClimateTemperature() {
    // En Nether y End el cielo de Beta no utiliza este campo climático del Overworld.
    if (!hasSkylight) return BETA_SKY_TEMPERATURE;
#ifdef BETA_CLIMATE_USE_VARYING
    return beta173ClimateTemperatureVarying;
#else
    // El bridge suministra el campo de Beta a partir de la semilla real en mundos integrados.
    if (beta173LegacyClimateAvailable) return beta173LegacyClimateTemperature;
#if BETA_CLIMATE_SEED_CONFIGURED
    // Ruta heredada: ZIP específico de semilla, generado por configure_climate_pack.py.
    // cameraPositionInt + cameraPositionFract recuperan la posición de cámara.
    vec2 cameraWorldXZ = vec2(cameraPositionInt.xz) + cameraPositionFract.xz;
    vec2 playerWorldXZ = cameraWorldXZ - relativeEyePosition.xz;
    vec2 playerXZ = floor(playerWorldXZ);
    return beta173ClimateTemperature(playerXZ);
#else
    // Fallback automático y universal sin bridge ni semilla manual: temperatura base
    // del bioma actual que Iris actualiza con el jugador. No es el ruido histórico exacto,
    // pero evita el valor neutral fijo y funciona en cualquier mundo/servidor.
    return temperature;
#endif
#endif
}

// BiomeGenBase.getSkyColorByTemp. El bridge calcula primero el RGB con Java
// para conservar la cuantización HSBtoRGB de 8 bits; en el ZIP puro usamos Iris temperature.
vec3 beta173SkyBaseColor() {
    if (beta173LegacyClimateAvailable) return beta173LegacySkyRgb;
    float t = clamp(beta173SkyClimateTemperature() / 3.0, -1.0, 1.0);
    return beta173Hsb(0.62222224 - t * 0.05, 0.5 + t * 0.1, 1.0);
}

// World.getSkyColor + BiomeGenBase.getSkyColorByTemp
vec3 beta173SkyColor() {
    vec3 col = beta173SkyBaseColor() * beta173DayFactor();

    float rain = beta173Rain();
    if (rain > 0.0) {
        float gray = dot(col, vec3(0.3, 0.59, 0.11)) * 0.6;
        float k = 1.0 - rain * 0.75;
        col = col * k + vec3(gray) * (1.0 - k);
    }

    float thunder = beta173Thunder();
    if (thunder > 0.0) {
        float gray = dot(col, vec3(0.3, 0.59, 0.11)) * 0.2;
        float k = 1.0 - thunder * 0.75;
        col = col * k + vec3(gray) * (1.0 - k);
    }
    return col;
}

// WorldProvider.func_4096_a + EntityRenderer.updateFogColor
vec3 beta173FogColor() {
    // Nether: reproduce el color de WorldProviderHell.func_4096_a de Beta 1.7.3.
    // End: usar el color de niebla nativo de la dimensión moderna, no inventar un color Beta.
    if (!hasSkylight) {
        if (hasCeiling) return vec3(0.2, 0.03, 0.03);
        return fogColor;
    }

    // La ruta del Overworld conserva la fórmula histórica de v0.8.
    float d = beta173DayFactor();
    vec3 fog = vec3(0.7529412, 0.84705883, 1.0) * vec3(d * 0.94 + 0.06, d * 0.94 + 0.06, d * 0.91 + 0.09);
    fog += (beta173SkyColor() - fog) * BETA_FOG_SKY_BLEND;

    float rain = beta173Rain();
    if (rain > 0.0) {
        fog.rg *= 1.0 - rain * 0.5;
        fog.b *= 1.0 - rain * 0.4;
    }

    float thunder = beta173Thunder();
    if (thunder > 0.0) {
        fog *= 1.0 - thunder * 0.5;
    }
    return fog;
}

// World.getStarBrightness
float beta173StarBrightness() {
    float v = clamp(1.0 - (cos(beta173CelestialAngle() * BETA_PI * 2.0) * 2.0 + 0.75), 0.0, 1.0);
    return v * v * 0.5;
}

// EntityRenderer.setupFog: lineal en aire (inicio al 25%), exponencial en agua y lava
vec3 beta173ApplyFog(vec3 color, float dist) {
#ifdef BETA_FOG
    if (isEyeInWater == 1) {
        return mix(vec3(0.02, 0.02, 0.2), color, exp(-0.1 * dist));
    }
    if (isEyeInWater == 2) {
        return mix(vec3(0.6, 0.1, 0.0), color, exp(-2.0 * dist));
    }

    // End moderno: respetar el modo, color, densidad y distancias nativas de Iris/Minecraft.
    // Los modos corresponden a GL_EXP, GL_EXP2 y GL_LINEAR.
    if (!hasSkylight && !hasCeiling) {
        float endNativeFogStart = max(fogStart, 0.0);
        float endNativeFogEnd = max(fogEnd, endNativeFogStart + 0.001);
        float endNativeFogFactor;
        if (fogMode == 2048) {
            endNativeFogFactor = exp(-max(fogDensity, 0.0) * dist);
        } else if (fogMode == 2049) {
            float densityDistance = max(fogDensity, 0.0) * dist;
            endNativeFogFactor = exp(-(densityDistance * densityDistance));
        } else {
            float nativeFogRange = max(endNativeFogEnd - endNativeFogStart, 0.001);
            endNativeFogFactor = clamp((endNativeFogEnd - dist) / nativeFogRange, 0.0, 1.0);
        }
        return mix(fogColor, color, clamp(endNativeFogFactor, 0.0, 1.0));
    }

    // Overworld conserva el perfil v0.8; el Nether comienza la niebla en distancia cero.
    bool isNether = !hasSkylight && hasCeiling;
    float betaFogEnd = BETA_FOG_END;
    float betaFogStart = isNether ? 0.0 : betaFogEnd * 0.25;
    float f = clamp((betaFogEnd - dist) / (betaFogEnd - betaFogStart), 0.0, 1.0);
    return mix(beta173FogColor(), color, f);
#else
    return color;
#endif
}

// RenderGlobal.renderSky: el domo se dibuja con niebla activa, asi que el cielo
// pasa de color de cielo (arriba) a color de niebla (horizonte). Debajo del horizonte
// se dibuja un segundo disco oscuro. 'up' = seno de la elevacion de la mirada.
vec3 beta173SkyGradient(float up) {
    vec3 sky = beta173SkyColor();
    vec3 base = up >= 0.0 ? sky : vec3(sky.r * 0.2 + 0.04, sky.g * 0.2 + 0.04, sky.b * 0.6 + 0.1);

    float dist = 16.0 / max(abs(up), 0.0005);
    float betaFogEnd = BETA_FOG_END;
    float betaFogStart = betaFogEnd * 0.25;
    float f = clamp((betaFogEnd - dist) / (betaFogEnd - betaFogStart), 0.0, 1.0);
#ifndef BETA_FOG
    f = 1.0;
#endif
    return mix(beta173FogColor(), base, f);
}

// ---- fin /lib/beta173.glsl ----

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out float viewDist;
flat out float beta173ClimateTemperatureVarying;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    lmcoord = lmcoord / (30.0 / 32.0) - (1.0 / 32.0);
    glcolor = gl_Color;
    viewDist = length((gl_ModelViewMatrix * gl_Vertex).xyz);
    // Se calcula por vértice: evita ejecutar 4 octavas de ruido en cada fragmento de terreno.
    beta173ClimateTemperatureVarying = beta173SkyClimateTemperature();
}
