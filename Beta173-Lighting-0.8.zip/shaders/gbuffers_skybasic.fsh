#version 330 compatibility

// ---- /lib/beta173.glsl ----
// Beta173 Lighting - funciones portadas desde el codigo de Minecraft Beta 1.7.3
// Referencia: WorldProvider, WorldProviderHell, World, EntityRenderer y RenderGlobal
// (https://github.com/jacobo-mc/mc_b1.7.3_release)

// ---- /lib/config.glsl ----
// Beta173 Lighting — reconstruccion de la distancia de renderizado de Beta 1.7.3.
// Selector manual: 0 = Far, 1 = Normal, 2 = Short, 3 = Tiny.
// Esto reproduce la matematica historica; no controla los chunks de Iris.

#define BETA_THUNDER
#define BETA_NETHER_AMBIENT
#define BETA_FOG

// Equivalente a GameSettings.renderDistance en Beta 1.7.3.
#define BETA_RENDER_DISTANCE 0

// EntityRenderer.setupCameraTransform y EntityRenderer.updateFogColor.
#if BETA_RENDER_DISTANCE == 0
    #define BETA_FOG_END 256.0
    #define BETA_FOG_SKY_BLEND 0.2928932
#elif BETA_RENDER_DISTANCE == 1
    #define BETA_FOG_END 128.0
    #define BETA_FOG_SKY_BLEND 0.2401643
#elif BETA_RENDER_DISTANCE == 2
    #define BETA_FOG_END 64.0
    #define BETA_FOG_SKY_BLEND 0.1591036
#elif BETA_RENDER_DISTANCE == 3
    #define BETA_FOG_END 32.0
    #define BETA_FOG_SKY_BLEND 0.0
#else
    #error BETA_RENDER_DISTANCE debe ser 0, 1, 2 o 3
#endif

// Aproximacion neutral: falta recuperar la temperatura real del bioma.
#define BETA_SKY_TEMPERATURE 0.5

// ---------------------------------------------------------------------------
// Estrellas, nubes y diagnostico (v0.8)
// ---------------------------------------------------------------------------

// Estrellas de Beta dibujadas por este shader dentro del cielo (RenderGlobal.renderStars:
// java.util.Random(10842), 1500 intentos -> 780 estrellas, radio 100, mismo tamano y rotacion).
// No dependen del pase de estrellas del motor, que se descarta. Comenta la linea para volver
// al pase del motor.
#define BETA_STAR_FIELD

// Color de las nubes:
//   0 = color y sombreado de Beta (World.drawClouds + caras 1.0 / 0.7 / 0.9 / 0.8). Ignora el
//       color del motor, asi que no puede haber oscurecimiento doble.
//   1 = solo el color que da el motor, sin tocarlo.
//   2 = comportamiento de v0.7.2: el color de Beta se multiplica sobre el del motor.
#define BETA_CLOUD_COLOR_MODE 0

// Altura de las nubes. Beta: WorldProvider.getCloudHeight() = 108, mas 0.33 en el render.
// BETA_VANILLA_CLOUD_HEIGHT es la altura que usa el juego moderno (192.33 desde 1.18).
// Comenta BETA_CLOUD_HEIGHT_FIX para dejar las nubes a la altura del juego.
#define BETA_CLOUD_HEIGHT_FIX
#define BETA_VANILLA_CLOUD_HEIGHT 192.33
#define BETA_CLOUD_HEIGHT 108.33

#ifdef BETA_CLOUD_HEIGHT_FIX
    #define BETA_CLOUD_BASE BETA_CLOUD_HEIGHT
#else
    #define BETA_CLOUD_BASE BETA_VANILLA_CLOUD_HEIGHT
#endif

// BETA_DEBUG:
//   0 = apagado (comportamiento normal)
//   1 = cada etapa del cielo se pinta de un color y las nubes salen rojas y opacas:
//         azul = SKY, naranja = SUNSET, MAGENTA = STARS, verde = CUSTOM_SKY,
//         rojo oscuro = VOID, AMARILLO = etapa no reconocida
//   2 = estrellas de Beta al maximo brillo (aunque sea de dia, para ver el mapa)
//   3 = el cielo muestra uniformes: R = lluvia, G = tormenta, B = brillo de estrellas x2
//       (si todo el cielo sale BLANCO, el uniforme hasSkylight no llega al shader)
//   4 = anillo CIAN alrededor de donde Beta pone el sol y anillo NARANJA donde pone la luna;
//       si el sol y la luna del juego quedan centrados en sus anillos, el marco de las estrellas es correcto
#define BETA_DEBUG 0

// ---- fin /lib/config.glsl ----

uniform int worldTime;
uniform float rainStrength;
uniform float thunderStrength; // Iris lo entrega ya ponderado por la lluvia, igual que getWeightedThunderStrength
uniform bool hasSkylight;      // false en Nether y End
uniform bool hasCeiling;       // true en el Nether vanilla de Iris
uniform float far;             // distancia de renderizado de Iris, en bloques
uniform int isEyeInWater;      // 0 aire, 1 agua, 2 lava

const float BETA_PI = 3.14159265359;

float beta173Rain() {
    return rainStrength;
}

float beta173Thunder() {
#ifdef BETA_THUNDER
    return thunderStrength;
#else
    return 0.0;
#endif
}

float beta173CelestialAngle() {
    float angle = mod(float(worldTime), 24000.0) / 24000.0 - 0.25;
    if (angle < 0.0) angle += 1.0;
    if (angle > 1.0) angle -= 1.0;

    float original = angle;
    angle = 1.0 - (cos(angle * BETA_PI) + 1.0) / 2.0;
    return original + (angle - original) / 3.0;
}

// cos(angulo * 2pi) * 2 + 0.5, limitado a 0..1 (base de cielo, niebla y luz)
float beta173DayFactor() {
    return clamp(cos(beta173CelestialAngle() * BETA_PI * 2.0) * 2.0 + 0.5, 0.0, 1.0);
}

// World.calculateSkylightSubtracted
float beta173SkySubtracted() {
    float f = beta173DayFactor();
    f *= 1.0 - beta173Rain() * 5.0 / 16.0;
    f *= 1.0 - beta173Thunder() * 5.0 / 16.0;
    return floor((1.0 - f) * 11.0);
}

// WorldProvider.generateLightBrightnessTable (0.1 en el Nether)
float beta173Ambient() {
#ifdef BETA_NETHER_AMBIENT
    return hasSkylight ? 0.05 : 0.1;
#else
    return 0.05;
#endif
}

float beta173Brightness(float level) {
    float ambient = beta173Ambient();
    float inverted = 1.0 - level / 15.0;
    return (1.0 - inverted) / (inverted * 3.0 + 1.0) * (1.0 - ambient) + ambient;
}

// Nivel de luz efectivo: max(luz de bloque, luz de cielo - restado)
float beta173LightLevel(vec2 lm) {
    // Beta 1.7.3 trabaja con niveles enteros 0..15. No interpolar niveles:
    // el lightmap moderno solo se usa como entrada aproximada para recuperar esos niveles.
    float block = floor(clamp(lm.x, 0.0, 1.0) * 15.0 + 0.5);
    float sky = floor(clamp(lm.y, 0.0, 1.0) * 15.0 + 0.5);
    return max(block, max(0.0, sky - beta173SkySubtracted()));
}

// Equivalente a java.awt.Color.getHSBColor
vec3 beta173Hsb(float h, float s, float b) {
    vec3 k = vec3(1.0, 2.0 / 3.0, 1.0 / 3.0);
    vec3 p = abs(fract(vec3(h) + k) * 6.0 - 3.0);
    return b * mix(vec3(1.0), clamp(p - 1.0, 0.0, 1.0), s);
}

// World.getSkyColor + BiomeGenBase.getSkyColorByTemp
vec3 beta173SkyColor() {
    float t = clamp(BETA_SKY_TEMPERATURE / 3.0, -1.0, 1.0);
    vec3 col = beta173Hsb(0.62222224 - t * 0.05, 0.5 + t * 0.1, 1.0) * beta173DayFactor();

    float rain = beta173Rain();
    if (rain > 0.0) {
        float gray = dot(col, vec3(0.3, 0.59, 0.11)) * 0.6;
        float k = 1.0 - rain * 0.75;
        col = col * k + vec3(gray) * (1.0 - k);
    }

    float thunder = beta173Thunder();
    if (thunder > 0.0) {
        float gray = dot(col, vec3(0.3, 0.59, 0.11)) * 0.2;
        float k = 1.0 - thunder * 0.75;
        col = col * k + vec3(gray) * (1.0 - k);
    }
    return col;
}

// WorldProvider.func_4096_a + EntityRenderer.updateFogColor
vec3 beta173FogColor() {
    float d = beta173DayFactor();
    vec3 fog = vec3(0.7529412, 0.84705883, 1.0) * vec3(d * 0.94 + 0.06, d * 0.94 + 0.06, d * 0.91 + 0.09);
    fog += (beta173SkyColor() - fog) * BETA_FOG_SKY_BLEND;

    float rain = beta173Rain();
    if (rain > 0.0) {
        fog.rg *= 1.0 - rain * 0.5;
        fog.b *= 1.0 - rain * 0.4;
    }

    float thunder = beta173Thunder();
    if (thunder > 0.0) {
        fog *= 1.0 - thunder * 0.5;
    }
    return fog;
}

// World.getStarBrightness
float beta173StarBrightness() {
    float v = clamp(1.0 - (cos(beta173CelestialAngle() * BETA_PI * 2.0) * 2.0 + 0.75), 0.0, 1.0);
    return v * v * 0.5;
}

// EntityRenderer.setupFog: lineal en aire (inicio al 25%), exponencial en agua y lava
vec3 beta173ApplyFog(vec3 color, float dist) {
#ifdef BETA_FOG
    if (isEyeInWater == 1) {
        return mix(vec3(0.02, 0.02, 0.2), color, exp(-0.1 * dist));
    }
    if (isEyeInWater == 2) {
        return mix(vec3(0.6, 0.1, 0.0), color, exp(-2.0 * dist));
    }
    bool isNether = !hasSkylight && hasCeiling;

    // El End no debe heredar automaticamente la niebla del Nether.
    if (!hasSkylight && !isNether) return color;

    // Distancia reconstruida desde GameSettings.renderDistance de Beta.
    float fogEnd = BETA_FOG_END;
    float fogStart = isNether ? 0.0 : fogEnd * 0.25;
    float f = clamp((fogEnd - dist) / (fogEnd - fogStart), 0.0, 1.0);
    return mix(beta173FogColor(), color, f);
#else
    return color;
#endif
}

// RenderGlobal.renderSky: el domo se dibuja con niebla activa, asi que el cielo
// pasa de color de cielo (arriba) a color de niebla (horizonte). Debajo del horizonte
// se dibuja un segundo disco oscuro. 'up' = seno de la elevacion de la mirada.
vec3 beta173SkyGradient(float up) {
    vec3 sky = beta173SkyColor();
    vec3 base = up >= 0.0 ? sky : vec3(sky.r * 0.2 + 0.04, sky.g * 0.2 + 0.04, sky.b * 0.6 + 0.1);

    float dist = 16.0 / max(abs(up), 0.0005);
    float fogEnd = BETA_FOG_END;
    float fogStart = fogEnd * 0.25;
    float f = clamp((fogEnd - dist) / (fogEnd - fogStart), 0.0, 1.0);
#ifndef BETA_FOG
    f = 1.0;
#endif
    return mix(beta173FogColor(), base, f);
}

// ---- fin /lib/beta173.glsl ----

uniform int renderStage;
uniform float viewWidth;
uniform float viewHeight;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform mat4 gbufferProjectionInverse;
uniform sampler2D noisetex; // mapa de estrellas de Beta (shaders.properties: texture.noise)

in vec4 glcolor;

out vec4 fragColor;

// Marco local de Beta -> mundo: Rx(theta) y luego Ry(-90), como el sol y la luna del juego.
// Aqui se hace la inversa: direccion de mundo -> marco local de Beta (sol del angulo 0 en +Y).
vec3 beta173WorldToStarFrame(vec3 d) {
    float theta = beta173CelestialAngle() * BETA_PI * 2.0;
    float s = sin(theta);
    float c = cos(theta);
    return vec3(d.z, d.y * c - d.x * s, -d.y * s - d.x * c);
}

// Cobertura 0..1 de las estrellas de Beta en esa direccion del marco local
float beta173StarCoverage(vec3 local) {
    vec2 uv = vec2(atan(local.x, local.z) / (BETA_PI * 2.0) + 0.5,
                   asin(clamp(local.y, -1.0, 1.0)) / BETA_PI + 0.5);
    return step(0.5, texture(noisetex, uv).r);
}

void main() {
#if BETA_DEBUG == 1
    // Diagnostico: que etapa de Iris llega a este programa
    vec3 stageColor = vec3(1.0, 1.0, 0.0); // amarillo: etapa no reconocida
#ifdef MC_RENDER_STAGE_SKY
    if (renderStage == MC_RENDER_STAGE_SKY) stageColor = vec3(0.0, 0.5, 1.0);        // azul
#endif
#ifdef MC_RENDER_STAGE_SUNSET
    if (renderStage == MC_RENDER_STAGE_SUNSET) stageColor = vec3(1.0, 0.5, 0.0);     // naranja
#endif
#ifdef MC_RENDER_STAGE_STARS
    if (renderStage == MC_RENDER_STAGE_STARS) stageColor = vec3(1.0, 0.0, 1.0);      // magenta
#endif
#ifdef MC_RENDER_STAGE_VOID
    if (renderStage == MC_RENDER_STAGE_VOID) stageColor = vec3(0.4, 0.0, 0.0);       // rojo oscuro
#endif
#ifdef MC_RENDER_STAGE_CUSTOM_SKY
    if (renderStage == MC_RENDER_STAGE_CUSTOM_SKY) stageColor = vec3(0.0, 1.0, 0.0); // verde
#endif
    fragColor = vec4(stageColor, 1.0);
    return;
#endif

#if BETA_DEBUG == 3
    // Diagnostico: blanco = hasSkylight no llega al shader
    if (!hasSkylight) {
        fragColor = vec4(1.0);
        return;
    }
#endif

    // Nether / End: dejar el cielo como lo dibuja el juego
    if (!hasSkylight) {
        fragColor = glcolor;
        return;
    }

#ifdef MC_RENDER_STAGE_STARS
    if (renderStage == MC_RENDER_STAGE_STARS) {
#ifdef BETA_STAR_FIELD
        // Las estrellas se dibujan mas abajo, dentro del cielo: descartar las del motor
        discard;
#else
        // Beta: glColor4f(b, b, b, b) con b = brillo de estrellas * (1 - lluvia)
        float b = beta173StarBrightness() * (1.0 - beta173Rain());
        fragColor = vec4(vec3(b), b);
        return;
#endif
    }
#endif

#ifdef MC_RENDER_STAGE_SUNSET
    if (renderStage == MC_RENDER_STAGE_SUNSET) {
        // El abanico de amanecer/atardecer usa la misma formula que Beta
        fragColor = glcolor;
        return;
    }
#endif

    vec4 ndc = vec4(gl_FragCoord.xy / vec2(viewWidth, viewHeight) * 2.0 - 1.0, 1.0, 1.0);
    vec4 viewPos = gbufferProjectionInverse * ndc;
    vec3 dirView = normalize(viewPos.xyz / viewPos.w);
    float up = dot(dirView, normalize(gbufferModelView[1].xyz));

#if BETA_DEBUG == 3
    // Diagnostico: R = lluvia, G = tormenta, B = brillo de estrellas x2
    fragColor = vec4(beta173Rain(), beta173Thunder(), beta173StarBrightness() * 2.0, 1.0);
    return;
#endif

    vec3 color = beta173SkyGradient(up);

#ifdef BETA_STAR_FIELD
    // Beta mezcla las estrellas con (SRC_ALPHA, ONE) y color (b, b, b, b): suma b * b
    float b = beta173StarBrightness() * (1.0 - beta173Rain());
#if BETA_DEBUG == 2
    b = 1.0;
#endif
    if (b > 0.0 && up > 0.0) {
        vec3 dirWorld = mat3(gbufferModelViewInverse) * dirView;
        float coverage = beta173StarCoverage(beta173WorldToStarFrame(dirWorld));
        color += vec3(coverage * b * b);
    }
#endif

#if BETA_DEBUG == 4
    // Diagnostico: anillos de 2 grados alrededor de donde Beta pone el sol (+Y local) y la luna (-Y local)
    {
        vec3 dirWorld = mat3(gbufferModelViewInverse) * dirView;
        vec3 local = beta173WorldToStarFrame(dirWorld);
        float ang = degrees(acos(clamp(abs(local.y), 0.0, 1.0)));
        if (local.y > 0.0 && abs(ang - 25.0) < 1.0) color = vec3(0.0, 1.0, 1.0);
        if (local.y < 0.0 && abs(ang - 20.0) < 1.0) color = vec3(1.0, 0.5, 0.0);
    }
#endif

    fragColor = vec4(color, 1.0);
}
